#-------------------------------------------------#
# Title: Justin Jameson Mod5.py version 1.15
# Dev:   Justin Jameson
# Date: 12 Aug 18
'''Desc: A script that manages a to-do list.
1. When the program starts it loads content from a txt file into a Python dictionary.
2. Once loaded the dictionary is added to a python list object to be managed as a table.
3. Display the list to the user.
4. The script will display a menu of options.
    1. Show Current Data.
    2. Add a New Item.
    3. Remove an Existing Item.
    4. Save Data to File.
    5. Exit Program.
5. Upon exit, save the data back to the txt file.
 '''
# ChangeLog: (Who, When, What)
#-------------------------------------------------#
#-- Imports --#
# import all needed functions

#-- Data --#
# declare variables and constants
# object variable to open the text file: objToDo
# dictionary variable to extract data from the text file: dicToDotxt
# variable to extract rows from the text file: strRow
# variable to print rows for user: objRow
# variable to assign read lines of text from txt file: txtLines
# variable to define key form text file: strKey
# variable to define value from text file: strValue
# variable to define input for what the user would like to do next: intInput
# variable to remove dictionary Key from list: dicRemoveKey
# variable to remove dictionary Value from list: dicRemoveValue

#-- Processing --#
# perform tasks

# Task 1, on start load content from a txt file into a python dictionary.
# Open the text file to gain access to the file contents.
objToDo = open("C:\_PythonClass\ToDo.txt", "r+")
# Read the text file and store the information as a variable.
txtLines = objToDo.readlines()
# Create an empty list to store the iterated dictionaries.
lstToDotxt = []
dicToDotxt = {}
# Loop through the text lines to extract data and create the dictionary.
for strRow in txtLines:
    # Unpack strRow into keys and values, use .strip to take out \n and .split to break at ','.
    strKey, strValue = strRow.strip().split(",")
    # Write the values to the dictionary, assign heading "Task" and "Priority"
    dicToDotxt={"Task": strKey, "Priority": strValue}
    # Task 2, Once loaded the dictionary is added to a python list object to be managed as a table.\
    # Append the list with the new values.
    lstToDotxt.append(dicToDotxt)
# close the txt file
objToDo.close()
# define the function to Show Current Data.
def ShowCurrentData():
    # Task 3, Display the list to the user.
    print("\nThe following are your Tasks and Priorities: ")
    for objRow in lstToDotxt:
        print(objRow)
# define the function to add new item.
def AddNewItem():
    # Warn the users that they may overwrite data
    print("WARNING: if you enter the same task name, you will overwrite the original task:")
    # Collect the Key and Value from the user.
    strKey = input("Enter new task: ")
    strValue = input("Enter the priority for the new task (High, Med, Low): ")
    # Add Key and Value to the dictionary under the headings "Task" and "Priority".
    dicToDotxt ={"Task":strKey, "Priority":strValue}
    # Append dictionary to the list.
    lstToDotxt.append(dicToDotxt)
    print("\n""\n""Task","'",strKey,"'", "has been added, with priority","'", strValue, "'.")
    ShowCurrentData()
# define the function to remove exiting item.
def RemoveExistingItem():
    # print tasks for review
    ShowCurrentData()
    # Get the key for the task the user wants to remove.
    dicRemoveKey = input("Which task would you like to remove? (NOTE: input is case sensitive) ")
    # Get the value for the task the user wants to remove.
    dicRemoveValue = input("Enter the current assigned priority of High, Med, Low (NOTE: input is case sensitive): ")
    # create the dictionary to remove selected task.
    diclstRemove = {"Task":dicRemoveKey, "Priority":dicRemoveValue}
    lstToDotxt.remove(diclstRemove)
    print(diclstRemove, "has been removed from the list.")
    # Show updated data for verification.
    ShowCurrentData()

# define the function to save data to file.
def SaveData():
   # open the text file and overwrite (w) all information.
   objToDo = open("C:\_PythonClass\ToDo.txt", "w")
   for i in lstToDotxt:
       objToDo.write(i["Task"]+ ","+i["Priority"] + "\n")
   objToDo.close()

# define the function to exit program
def ExitSave():
    SaveData()
    exit()




#-- Presentation (Input/Output) --#
# Task 3, Display the list to the user, this is a user defined function see 'Processing' above.
ShowCurrentData()
# Task 4, The script will display a menu of options, get user input.
while(True):
    print("\n""What would you like to do next?")
    print("\n""1. Show Current Data.""\n""2. Add a New Item.""\n""3. Remove an Existing Item.""\n""4. Save Data to File."\
          "\n5. Exit Program and Save Data. ")
    intInput = input("Enter a number 1-5: ")
    if intInput == "1": ShowCurrentData()
    elif intInput == "2": AddNewItem()
    elif intInput == "3": RemoveExistingItem()
    elif intInput == "4": SaveData()
    elif intInput == "5": ExitSave()
    else: print ("Please enter a number 1-5: ")
# send program output
